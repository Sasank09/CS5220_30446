package com.example.ch33_networking;

import java.io.*;
import java.net.*;
import java.util.*;

import com.sun.security.ntlm.Server;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
/*  We will put these lines in our program, just saving us some typing
Platform.runLater(() ->
               ta.appendText("BMI server started at " + new Date() + "\n"));

Platform.runLater(() ->
               ta.appendText("Connected to client  at " + new Date() + "\n"));
*/

/*public class BMI_Server extends Application {
  // Text area for displaying contents
  private TextArea ta = new TextArea();

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    ta.setWrapText(true);
   
    // Create a scene and place it in the stage
    Scene scene = new Scene(new ScrollPane(ta), 200, 200);
    primaryStage.setTitle("BMI Server"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    //create a thread that connects to the client

  }

  public void connectToClient() throws IOException {
    try{
      //create a server socket

      //Create input and out streams


      //continuously serve the client

  }  //end connectToClient


  */
  /**
   * The pulic main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
 /* public static void main(String[] args) {
    launch(args);
  }
}
*/

